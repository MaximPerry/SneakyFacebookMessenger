
 onload = () => {
    //webview.style.display = "initial";
    const loadstart = () => {
        //webview.openDevTools();
        webview.insertCSS("._mh6, ._wsc {width: 70%;} ._4_j5 {display:none !important;} ._1t2u {width: 60% !important; border-left: none !important;} html {overflow: hidden !important;} img {display: none !important;} ._1enh {min-width:30px !important;} ._4sp8 {font-size: initial !important;} ._43by._43by {color: black !important; background-color: white !important;} ._hh7 {background-color: white !important;} ._4ld- div {background-image: none !important;} ._4rv4 {display: none !important;} @media (max-with:700px !important) {}");
    }
    webview.addEventListener('did-start-loading', loadstart)
    //webview.addEventListener('did-stop-loading', loadstop)
}

const webview = document.querySelector('webview');
//webview.style.display = "none";